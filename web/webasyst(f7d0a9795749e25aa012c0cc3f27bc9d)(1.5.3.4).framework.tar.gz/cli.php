#!/usr/bin/php
<?php
require_once(dirname(__FILE__).'/wa-system/cli.php');