<?php

return array(
    'name' => /*_wp*/('Orders'),
    'size' => array('2x2', '2x1', '1x1'),
    'img' => 'img/orders.png',
    'version'=>'1.2',
    'vendor' => 'webasyst',
    'rights' => array(
        'shop' => array(
            'orders' => true
        )
    )
);
