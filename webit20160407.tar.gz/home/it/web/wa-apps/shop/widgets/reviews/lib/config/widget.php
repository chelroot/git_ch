<?php

return array(
    'name' => /*_wp*/('Reviews'),
    'size' => array('2x2', '1x1'),
    'img' => 'img/reviews.png',
    'version' => '1.1',
    'vendor' => 'webasyst',
);
