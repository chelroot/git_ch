<?php

return array(
    'name' => /*_wp*/('KPI'),
    'size' => array('2x2', '2x1', '1x1'),
    'img' => 'img/kpi.png',
    'version'=>'1.0',
    'vendor' => 'webasyst',
    'rights' => array(
        'shop' => array(
            'reports' => true,
        )
    )
);
