<?php
return array (
  'name' => /*_wp*/('Customers'),
  'size' => 
  array (
    0 => '2x2',
    1 => '2x1',
    2 => '1x1',
  ),
  'img' => 'img/customers.png',
  'version' => '1.0',
  'vendor' => 'webasyst',
  'rights' => array(
      'shop' => array(
          'reports' => true,
      )
  )
);
