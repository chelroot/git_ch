<?php

class shopPageParamsModel extends waPageParamsModel
{
    protected $table = 'shop_page_params';
}