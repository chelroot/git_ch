<?php

class shopPageModel extends waPageModel
{
    protected $app_id = 'shop';
    protected $table = 'shop_page';
}