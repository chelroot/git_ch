<?php

class shopStorefrontsSettingsAction extends waViewAction
{

}
