<?php
return array (
  'name' => _wp('Cam pictures'),
  'description' => _wp('Personal cabinet for secure cams'),
  'icon' => 'img/campic16.png',
  'img' => 'img/campic16.png',
  'version' => '1.0.0',
  'vendor' => '964801',
  'frontend' => true,
  'handlers' =>
  array (
      'frontend_my_nav'   => 'frontendMy',
      'signup'            => 'signupHandler',
  ),
);
