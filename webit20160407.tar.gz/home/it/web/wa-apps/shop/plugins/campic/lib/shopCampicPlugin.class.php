<?php

class shopCampicPlugin extends shopPlugin
{
    public static $server = 'site.camera';

    /**
     * @var waView $view
     */
    private static $view;
    private static function getView()
    {
        if (!isset(self::$view)) {
            self::$view = waSystem::getInstance()->getView();
        }
        return self::$view;
    }

    /**
     * @var shopInvitePlugin $plugin
     */
    private static $plugin;
    private static function getPlugin()
    {
        if (!isset(self::$plugin)) {
            self::$plugin = wa()->getPlugin('campic');
        }
        return self::$plugin;
    }

    public function frontendMy() {
        $view = self::getView();
        $settings = $this->getSettings();
        $view->assign('settings', $settings);
        $shopUrl = wa()->getRouteUrl('shop/frontend');
        $view->assign('shop_url', $shopUrl);
        return $view->fetch($this->path . '/templates/actions/frontend/my_tab.html');
    }

    public function getPluginPath()
    {
        return $this->path;
    }

    /**
     * Обработчик хука signup
     *
     * @param waContact $contact
     */
    public function signupHandler($contact)
    {
        $token_model = new waApiTokensModel();
        $token_model->getToken('site.camera', $contact->getId(), 'campic');
    }
}
