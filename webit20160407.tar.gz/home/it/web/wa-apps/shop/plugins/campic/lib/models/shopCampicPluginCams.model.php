<?php

class shopCampicPluginCamsModel extends waModel
{
    protected $table = 'shop_campic_cams';

    public function getCams() {
        return $this->getByField('contact_id', wa()->getUser()->getId(), true);
    }

    public function saveCams($cams) {
        $this->deleteAllCams();
        $this->multipleInsert($cams);
    }

    public function deleteAllCams() {
        $this->deleteByField('contact_id', wa()->getUser()->getId());
    }
}
