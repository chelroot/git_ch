<?php
/**
 * Created by PhpStorm.
 * User: snark | itfrogs.ru
 * Date: 2/17/16
 * Time: 1:45 AM
 */

return array(
    'my/campic/'        => 'frontend/show',
    'campic/addcam'     => 'frontend/addcam',
    'campic/getcams'    => 'frontend/getcams',
    'campic/deletecam/' => 'frontend/deletecam',
);