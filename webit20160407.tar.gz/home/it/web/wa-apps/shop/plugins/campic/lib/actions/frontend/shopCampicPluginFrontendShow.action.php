<?php
/**
 * Created by PhpStorm.
 * User: snark | itfrogs.ru
 * Date: 2/17/16
 * Time: 1:50 AM
 */

class shopCampicPluginFrontendShowAction extends shopFrontendMyProfileAction
{


    public function execute()
    {
        $user = wa()->getUser();
        /**
         * @var shopCampicPlugin $plugin
         */
        $plugin = wa()->getPlugin('campic');
        $settings = $plugin->getSettings();

        if (!$user->getId()) {
            $this->redirect(wa()->getRouteUrl('/'));
        }

        $shopUrl = wa()->getAppUrl('shop');
        $this->view->assign('shop_url', $shopUrl);

        $settings = $plugin->getSettings();
        $this->view->assign('settings', $settings);
        $this->view->assign('plugin_id', 'campic');
        $this->view->assign('server', shopCampicPlugin::$server);
        $cams_model = new shopCampicPluginCamsModel();
        $this->view->assign('cams', $cams_model->getCams());

        $this->setLayout(new shopFrontendLayout());
        $this->setTemplate($plugin->getPluginPath() . '/templates/actions/frontend/campic.html');
        $this->getResponse()->setTitle(_wp('Secure cams'));
    }
}