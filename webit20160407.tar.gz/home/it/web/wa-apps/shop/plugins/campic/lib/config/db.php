<?php
/**
 * Created by PhpStorm.
 * User: snark | itfrogs.ru
 * Date: 2/16/16
 * Time: 3:05 AM
 */

return array(
    'shop_campic_cams' => array(
        'id' => array('int', 11, 'null' => 0, 'autoincrement' => 1),
        'contact_id' => array('int', 11, 'null' => 0),
        'server_id' => array('int', 11, 'null' => 0),
        'ftp_user_id' => array('int', 11, 'null' => 0),
        'user' => array('varchar', 20, 'null' => 0),
        'password' => array('varchar', 20, 'null' => 0),
        'url' => array('varchar', 255, 'null' => 0),
        'strategy' => array('tinyint', 1, 'null' => 0),
        'cam_num' => array('tinyint', 2, 'null' => 0),
        ':keys' => array(
            'PRIMARY' => array('id'),
        ),
    ),
);
