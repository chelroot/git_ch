<?php
/**
 * Created by PhpStorm.
 * User: snark | itfrogs.ru
 * Date: 2/25/16
 * Time: 10:03 PM
 */

class shopCampicPluginFrontendDeletecamController extends waJsonController
{
    /**
     * @var shopCampicPlugin $plugin
     */
    private static $plugin;

    /**
     * @var waView $view
     */
    private static $view;

    private static $token;

    public function execute()
    {
        $user = wa()->getUser();
        if ($user) {

            $options = array(
                'access_token' => self::$token,
                'format' => 'JSON',
            );

            $id = waRequest::get('id', 0, 'int');

            $url = 'http://'.shopCampicPlugin::$server.'/api.php?app=campic&method=cam.delete&cam_id=' . $id . '&';
            $url .= http_build_query($options,'','&');

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, '');
            $data = json_decode(curl_exec($ch));
            curl_close($ch);

            $cams = array();
            foreach ($data as $key => $cam) {
                $cams[$key] = (array)$cam;
            }

            $cams_model = new shopCampicPluginCamsModel();
            $cams_model->saveCams($cams);
            self::$view->assign('cams', $cams);

            $cams_template = self::$view->fetch(self::$plugin->getPluginPath() . '/templates/actions/frontend/cams.html');
            $this->response = $cams_template;
        }
        else {
            $this->setError(_wp('Access denied'));
        }
    }

    public function __construct($params = null)
    {
        self::$plugin = wa('shop')->getPlugin('campic');
        self::$view = wa()->getView();
        $token_model = new waApiTokensModel();
        self::$token = $token_model->getToken('site.camera', wa()->getUser()->getId(), 'campic');
    }

}
