<?php
class campicBackendAction extends waViewAction
{
    public function execute()
    {
        
        $message = 'Приложение Cam Pictures Generator';
        $this->view->assign('message', $message);
    }
}
