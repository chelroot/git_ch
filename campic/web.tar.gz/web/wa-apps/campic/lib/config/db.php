<?php

return array(
    'campic_cams' => array(
        'id' => array('int', 11, 'null' => 0, 'autoincrement' => 1),
        'contact_id' => array('int', 11, 'null' => 0),
        'ftp_id' => array('int', 11, 'null' => 0),
        'cam_num' => array('tinyint', 2, 'null' => 0),
        ':keys' => array(
            'PRIMARY' => array('id'),
        ),
    ),
);