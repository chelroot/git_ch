<?php
return array (
  '*' => 'frontend',
);
