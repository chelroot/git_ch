<?php
return array (
  'name' => 'Cam Pictures Generator',
  'icon' => 
  array (
    48 => 'img/campic48.png',
    96 => 'img/campic96.png',
  ),
  'version' => '1.0.0',
  'vendor' => '123456',
  'frontend' => true,
);
