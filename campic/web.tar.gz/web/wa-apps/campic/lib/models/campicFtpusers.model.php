<?php

class campicFtpusersModel extends waModel
{
    protected $table = 'users';
    protected $home = '/home/campic/web/wa-data/public/campic/cams/';
    protected $gid = 501;

    public function __construct($type = 'ftp')
    {
        parent::__construct($type);
    }

    public function add($userid, $password) {
        $last_uid = intval($this->select('MAX(uid)')->fetchField());
        $data = array(
            'userid'    => $userid,
            'passwd'    => $password,
            'uid'       => $last_uid + 1,
//            'gid'       => $last_uid + 1,
            'gid'       => 501,
            'home'     => $this->home . $userid,
            'shell'     => '/sbin/nologin',
        );

        $id = $this->insert($data);
        $data['id'] = $id;

        return $data;
    }

}
