<?php

class campicCamsModel extends waModel
{
    protected $table = 'campic_cams';

    public function getCams($contact_id) {
        return $this->getByField('contact_id', $contact_id, true);
    }
}
