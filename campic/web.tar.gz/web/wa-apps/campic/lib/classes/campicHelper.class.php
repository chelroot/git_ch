<?php

class campicHelper
{
    public static function getEmail($contact, $all = false)
    {
        $emails = $contact->get('email', 'value');
        if (empty($emails)) {
            return false;
        } else {
            if ($all) {
                return $emails;
            }
            else {
                return reset($emails);
            }
        }
    }

    public static function getCams($contact_id) {
        $cams_model = new campicCamsModel();
        $cams = $cams_model->getCams($contact_id);

        $results = array();
        $ftp_users_model = new campicFtpusersModel();
        foreach ($cams as $cam) {
            $results[] = array(
                'campic'    => $cam,
                'ftp'       => $ftp_users_model->getById($cam['ftp_id']),
            );
        }
        return $results;
    }
}