<?php

class campicCamAddMethod extends waAPIMethod
{
    protected $method = 'POST';

    public function execute()
    {
        $token = $this->get('access_token');
        $model = new waModel();
        $contact_id = $model->query('SELECT contact_id FROM wa_api_tokens WHERE token = s:token', array('token' => $token))->fetchField();
        $contact = new waContact($contact_id);
        $email = campicHelper::getEmail($contact);

        $fake_username = strstr($email, '@', true) . $contact_id;

        $cams_model = new campicCamsModel();

        $cams = $cams_model->getCams($contact_id);
        if (empty($cams)) {
            $num = 1;
        }
        else {
            $num = $cams[count($cams) - 1]['cam_num'] + 1;
        }

        $cam_name = $fake_username . '-' . $num;
        $password = substr(md5(microtime()), 0, 6);

        $ftp_users_model = new campicFtpusersModel();
        $ftp_user = $ftp_users_model->add($cam_name, $password);

        $data = array();
        if (!empty($ftp_user)) {
            $data = array(
                'contact_id' => $contact_id,
                'ftp_id' => $ftp_user['id'],
                'cam_num' => $num,
            );
            $data['id'] = $cams_model->insert($data);
        }

        $cams = campicHelper::getCams($contact_id);

        $this->response = array(
            'cams' => $cams,
        );
    }
}