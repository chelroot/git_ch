<?php

return array (
  '2798.help-pro.net' => 
  array (
    0 => 
    array (
      'url' => '*',
      'app' => 'site',
      'locale' => 'ru_RU',
    ),
  ),
);
//EOF