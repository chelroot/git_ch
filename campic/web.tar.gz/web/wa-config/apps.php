<?php

return array (
    'contacts' => true,
    'installer' => true,
    'site' => true,
    'campic' => true,
    'clock' => true,
    'news' => true,
    'weather' => true,
);
//EOF