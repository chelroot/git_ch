<?php

return array (
    'default' =>
        array (
            'host' => 'localhost',
            'port' => false,
            'user' => 'campic',
            'password' => 'zaq1xsw2',
            'database' => 'campic',
            'type' => 'mysqli',
        ),
    'ftp' =>
        array (
            'host' => 'localhost',
            'port' => false,
            'user' => 'proftpd',
            'password' => 'proftpd',
            'database' => 'proftpd',
            'type' => 'mysqli',
        ),
);
//EOF