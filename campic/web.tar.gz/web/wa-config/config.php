<?php
return array (
  'debug' => true,
  'identity_hash' => '5fe80607ce5f56d69e0728679cd91bd4',
  'mod_rewrite' => '1',
);
