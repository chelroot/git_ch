<?php
return array (
  '2798.help-pro.net' => 
  array (
    'auth' => true,
    'app' => 'site',
    'params' => 
    array (
      'button_caption' => 'Регистрация',
    ),
    'fields' => 
    array (
      'firstname' => 
      array (
        'caption' => 'Имя',
        'placeholder' => '',
      ),
      'lastname' => 
      array (
        'caption' => 'Фамилия',
        'placeholder' => '',
      ),
      'email' => 
      array (
        'caption' => 'Email',
        'placeholder' => '',
        'required' => true,
      ),
      'password' => 
      array (
        'caption' => 'Пароль',
        'placeholder' => '',
        'required' => true,
      ),
      'company' => 
      array (
        'caption' => 'Компания',
        'placeholder' => '',
      ),
    ),
  ),
);
