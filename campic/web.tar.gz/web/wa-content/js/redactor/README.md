# Redactor

[Redactor](http://imperavi.com/redactor/) is a WYSIWYG html editor. Distributed as part of Webasyst Framework package under the terms of [The OEM License](http://imperavi.com/redactor/license/).